package com.example.androidproject

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ItemDetailsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_item_details)

        // Get Data from Intent
        val itemName = intent.getStringExtra("itemName")
        val itemPrice = intent.getDoubleExtra("itemPrice", 0.0)
        val itemDescription = intent.getStringExtra("itemDescription")

        // Set Data in TextViews
        findViewById<TextView>(R.id.tvItemName).text = itemName
        findViewById<TextView>(R.id.tvItemPrice).text = "Price: $${itemPrice}"
        findViewById<TextView>(R.id.tvItemDescription).text = itemDescription
    }
}
