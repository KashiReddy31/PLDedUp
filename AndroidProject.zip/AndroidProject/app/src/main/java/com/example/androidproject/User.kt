package com.example.androidproject

data class User(
    val userId: String = "",
    val username: String = "",
    val email: String = ""
)
