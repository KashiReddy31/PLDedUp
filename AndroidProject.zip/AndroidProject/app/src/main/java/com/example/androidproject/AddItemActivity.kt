package com.example.androidproject

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.FirebaseDatabase
import kotlinx.android.synthetic.main.activity_add_item.*

class AddItemActivity : AppCompatActivity() {

    private val database = FirebaseDatabase.getInstance().reference.child("priceLists")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_item)

        btnSave.setOnClickListener {
            val itemName = etItemName.text.toString()
            val itemPrice = etItemPrice.text.toString().toDoubleOrNull()

            if (itemName.isNotEmpty() && itemPrice != null) {
                val newItem = PriceListItem(itemName, itemPrice)
                database.push().setValue(newItem)
                Toast.makeText(this, "Item added!", Toast.LENGTH_SHORT).show()
                finish()
            } else {
                Toast.makeText(this, "Please enter valid details", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
