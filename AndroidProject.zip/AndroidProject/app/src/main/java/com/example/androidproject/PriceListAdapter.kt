package com.example.androidproject

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import kotlinx.androidx.synthetic.main.item_price.view.*

class PriceListAdapter(private val items: List<PriceListItem>, private val context: Context) :
    RecyclerView.Adapter<PriceListAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_price, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.bind(item)

        // Click event
        holder.itemView.setOnClickListener {
            val intent = Intent(context, ItemDetailsActivity::class.java)
            intent.putExtra("ITEM_DETAILS", item)
            context.startActivity(intent)
        }
    }

    override fun getItemCount() = items.size

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bind(item: PriceListItem) {
            itemView.tvItemName.text = item.name
            itemView.tvItemPrice.text = "$${item.price}"

            // Load image using Glide
            Glide.with(itemView.context)
                .load(item.imageUrl)
                .placeholder(R.drawable.placeholder_image)
                .into(itemView.ivItemThumbnail)
        }
    }
}
