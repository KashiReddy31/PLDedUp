package com.example.androidproject

data class AppSettings(
    val isDarkMode: Boolean = false
)
