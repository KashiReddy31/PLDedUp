package com.example.androidproject

import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.database.*
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    private lateinit var database: FirebaseDatabase
    private lateinit var priceListRef: DatabaseReference
    private lateinit var priceListAdapter: PriceListAdapter
    private val priceListItems = mutableListOf<PriceListItem>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize Firebase Database
        database = FirebaseDatabase.getInstance()
        priceListRef = database.getReference("priceLists")

        // Setup RecyclerView
        rvPriceList.layoutManager = LinearLayoutManager(this)
        priceListAdapter = PriceListAdapter(priceListItems) { selectedItem ->
            openItemDetails(selectedItem)
        }
        rvPriceList.adapter = priceListAdapter

        // Load data from Firebase
        loadPriceList()

        // Floating Action Button for Adding Items
        val fabAddItem: FloatingActionButton = findViewById(R.id.fab_add_item)
        fabAddItem.setOnClickListener { showAddItemDialog() }

        // Bottom Navigation Setup
        val bottomNavigationView: BottomNavigationView = findViewById(R.id.bottom_navigation)
        bottomNavigationView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> true
                R.id.nav_add -> {
                    showAddItemDialog()
                    true
                }
                R.id.nav_settings -> {
                    toggleDarkMode()
                    true
                }
                else -> false
            }
        }
    }

    private fun loadPriceList() {
        priceListRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                priceListItems.clear()
                for (itemSnapshot in snapshot.children) {
                    val item = itemSnapshot.getValue(PriceListItem::class.java)
                    item?.let { priceListItems.add(it) }
                }
                priceListAdapter.notifyDataSetChanged()
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@MainActivity, "Failed to load items", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun showAddItemDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_add_item, null)
        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .setCancelable(false)
            .create()

        val etItemName = dialogView.findViewById<EditText>(R.id.etDialogItemName)
        val etItemPrice = dialogView.findViewById<EditText>(R.id.etDialogItemPrice)
        val etItemDescription = dialogView.findViewById<EditText>(R.id.etDialogItemDescription)
        val btnCancel = dialogView.findViewById<Button>(R.id.btnCancel)
        val btnAddItem = dialogView.findViewById<Button>(R.id.btnAddItem)

        btnCancel.setOnClickListener { dialog.dismiss() }

        btnAddItem.setOnClickListener {
            val name = etItemName.text.toString()
            val price = etItemPrice.text.toString().toDoubleOrNull()
            val description = etItemDescription.text.toString()

            if (name.isNotEmpty() && price != null) {
                val newItem = PriceListItem(name, price, description)
                saveItemToDatabase(newItem)
                dialog.dismiss()
            } else {
                Toast.makeText(this, "Please enter valid details", Toast.LENGTH_SHORT).show()
            }
        }

        dialog.show()
    }

    private fun saveItemToDatabase(item: PriceListItem) {
        val newItemRef = priceListRef.push()
        newItemRef.setValue(item)
            .addOnSuccessListener { Toast.makeText(this, "Item added!", Toast.LENGTH_SHORT).show() }
            .addOnFailureListener { Toast.makeText(this, "Failed to add item", Toast.LENGTH_SHORT).show() }
    }

    private fun toggleDarkMode() {
        val currentNightMode = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        if (currentNightMode == Configuration.UI_MODE_NIGHT_YES) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        }
        recreate()
    }

    private fun openItemDetails(item: PriceListItem) {
        val intent = Intent(this, ItemDetailsActivity::class.java).apply {
            putExtra("itemName", item.name)
            putExtra("itemPrice", item.price)
            putExtra("itemDescription", item.description)
        }
        startActivity(intent)
    }
}
