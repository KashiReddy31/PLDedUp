package com.example.androidproject

import android.view.View
import android.view.animation.AlphaAnimation
import android.view.animation.BounceInterpolator
import android.view.animation.TranslateAnimation

object AnimationUtils {

    fun fadeIn(view: View, duration: Long = 500) {
        val fadeIn = AlphaAnimation(0f, 1f).apply {
            this.duration = duration
            fillAfter = true
        }
        view.startAnimation(fadeIn)
    }

    fun bounce(view: View) {
        val bounceAnim = TranslateAnimation(0f, 0f, -20f, 0f).apply {
            duration = 500
            interpolator = BounceInterpolator()
        }
        view.startAnimation(bounceAnim)
    }
}
